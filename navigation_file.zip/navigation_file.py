import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32MultiArray
import serial  # Para comunicação UART
import time

class NavigationNode(Node):
    def __init__(self):
        super().__init__('navigation_node')
        
        # Inscrição para receber as distâncias dos sensores
        self.sensor_sub = self.create_subscription(
            Float32MultiArray,
            'navigation_node',
            self.sensor_callback,
            10
        )

        # Inicialização da comunicação UART com a ESP32
        self.ser = serial.Serial('/dev/ttyUSB0', 9600)  # Ajuste a porta conforme necessário
        time.sleep(2)  # Aguardar a inicialização da comunicação

        self.distances = []

    def sensor_callback(self, msg):
        self.distances = msg.data
        self.navigate()

    def navigate(self):
        # Verifica se há algum obstáculo nas distâncias dos sensores
        obstacle_detected = False
        for distance in self.distances:
            if distance < 0.2:  # Defina o limite de distância conforme necessário
                obstacle_detected = True
                break
        
        if obstacle_detected:
            self.get_logger().info("Obstáculo detectado! Desviando...")
            self.avoid_obstacle()
        else:
            self.move_forward()

    def move_forward(self):
        # Comando para mover para frente
        self.send_uart_command('F')

    def avoid_obstacle(self):
        # Comando para desviar quando um obstáculo é detectado
        self.send_uart_command('B')  # Mover para trás
        time.sleep(1)
        self.send_uart_command('L')  # Girar para a esquerda
        time.sleep(1)
        self.send_uart_command('F')  # Voltar a mover para frente

    def send_uart_command(self, command):
        # Função para enviar comando via UART para ESP32
        self.ser.write(command.encode())
        self.get_logger().info(f"Comando enviado via UART: {command}")

def main(args=None):
    rclpy.init(args=args)
    node = NavigationNode()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
